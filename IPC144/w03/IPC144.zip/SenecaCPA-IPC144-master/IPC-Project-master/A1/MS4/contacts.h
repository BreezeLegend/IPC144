/* -------------------------------------------
Name:
Student number:
Email:
Section:
Date:
----------------------------------------------
Assignment: 1
Milestone:  4
---------------------------------------------- */

// Structure type Name declaration (Milestone 1)
struct Name {
    char firstName[31];
    char middleInitial[7];
    char lastName[36];
};

// Structure type Address declaration 
// Place your code here... (from Milestone 1)




// Structure type Numbers declaration
// Place your code here... (from Milestone 1)




// Structure type Contact declaration
// Place your code here... (from Milestone 3)




//------------------------------------------------------
// Function Prototypes
//------------------------------------------------------

// ====== Milestone 4 =======

// Get and store from standard input the values for Name
// Place your code here...


// Get and store from standard input the values for Address
// Place your code here...


// Get and store from standard input the values for Numbers
// Place your code here...

