#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
    printf("********************************\n");
    printf("*** Welcome to C Programming ***\n");
    printf("********************************\n");

   return 0;
}